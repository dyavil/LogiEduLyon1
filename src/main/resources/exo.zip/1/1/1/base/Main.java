
public class Main {

    public static void main(String[] args) {
        //printStr(String);
        //printInt(int);
    }
    public void printStr(String s){
        System.out.println(“Chaine : “ + s);
	}
	public void printInt(int i){
		System.out.println(“Resultat : “ + i);
	}

}
