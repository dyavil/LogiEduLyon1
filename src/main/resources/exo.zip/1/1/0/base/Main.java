
public class Main {

    public static void main(String[] args) {
        int i = 3559;
        if(i == 12){
            printRes(“Bravo !”);
        }
        else{
            printRes(“Perdu !”);
        }

    }

	public void printRes(String s){
		    System.out.println(“Chaine : “ + s);
	}

}
