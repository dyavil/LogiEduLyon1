
public class Main {

    public static void main(String[] args) {
        int res = lapin(12);
        //Reponse : 144
        printInt(res);
    }
    public int lapin(int i){
        //TODO
        int res = 0;
        return res;
	}
	public void printInt(int i){
		System.out.println("Fibonacci de  12 : " + i);
	}

}
