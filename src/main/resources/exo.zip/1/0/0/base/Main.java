
public class Main {

    public static void main(String[] args) {
        
        //printRes(int, bool, float)
    }
	public void printRes(int i, bool b, float f){
        System.out.println(“Entier : “ + i + “ Booléen : “ + b + “ Nombre à virgule : “ + f);
	}
}
