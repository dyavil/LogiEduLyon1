public class Main{
	
	public static void main(String[] args){
		//printRes(int, boolean, double);
	}

	public void printRes(int i, boolean b, double d){
		System.out.println("Entier : " + i + " booléen : " + b + " Nombre à virgule : " + d);
	}
}